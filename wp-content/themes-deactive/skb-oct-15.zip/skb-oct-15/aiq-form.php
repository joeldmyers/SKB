<?php /* Template Name: AIQ Form */
get_header();

get_template_part( 'library/templates/content' , 'aiq-form' );

get_footer();