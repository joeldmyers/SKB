<?php /* Template Name: Contact */
get_header();

get_template_part( 'library/templates/content' , 'approach' );

get_footer();