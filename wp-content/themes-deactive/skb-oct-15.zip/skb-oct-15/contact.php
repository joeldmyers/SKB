<?php /* Template Name: Contact */

<?php get_header();

get_template_part( 'library/templates/content' , 'page' );

get_footer();