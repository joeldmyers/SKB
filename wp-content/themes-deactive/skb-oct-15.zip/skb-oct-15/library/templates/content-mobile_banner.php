<div class="fullscreen" style="background-image: url('<?php echo home_url( '/wp-content/themes/skb/library/images/mobile-banner.jpg' ); ?>'); background-position: center center; background-size: cover; min-height: 320px;">
    <div class="overlay" style="display: table; min-height: 320px; width: 100%; background-color: rgba(10,31,57,0.8);">
        <div style="display: table-cell; padding: 0 5px; color: white; font-weight: bold; text-align: center; vertical-align: middle;">
            <h3>ONLINE ACCESS FOR ACCREDITED INVESTORS TO SKB OFFERINGS</h3>
            <h5>SKB Is The Premier Real Estate Merchant Bank In The Western US</h5><br>
            <a class="btn btn-default btn-block center-block" style="max-width: 50%;" title="Get Started" href="/my-account">GET STARTED</a><br>
            <a class="btn btn-default btn-block center-block" style="max-width: 50%; margin-top: 5px; margin-bottom: 5px;" title="How to Invest" href="/how-to-invest">LEARN MORE</a>
        </div>         
    </div>
</div>