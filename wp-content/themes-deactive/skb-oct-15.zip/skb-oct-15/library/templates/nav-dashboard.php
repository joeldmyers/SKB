<div class="col-xs-12">
	<ul class="nav nav-tabs" role="tablist" id="investor-dashboard">
		<li role="presentation" class="active"><a href="#overview" aria-controls="overview" role="tab" data-toggle="tab">Overview</a></li>
		<li role="presentation"><a href="#investments" aria-controls="investments" role="tab" data-toggle="tab">My Investments</a></li>
		<li role="presentation"><a href="#history" aria-controls="history" role="tab" data-toggle="tab">My History</a></li>
		<!--<li role="presentation"><a href="#updates" aria-controls="updates" role="tab" data-toggle="tab">Investment Updates</a></li>
		<li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Messages</a></li>
		<li role="presentation"><a href="#taxes" aria-controls="taxes" role="tab" data-toggle="tab">Tax Center</a></li>-->
	</ul>
	<br><br>	
</div>