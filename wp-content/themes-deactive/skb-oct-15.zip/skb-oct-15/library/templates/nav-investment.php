<nav class="navbar navbar-inverse navbar-static-top">
	<div class="container">
		<ul id="menu-investments-header" class="nav navbar-nav">
			<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-active-deals-3 first-menu-item"><a href="/investments/#active-deals">Active Deals</a></li>
			<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-coming-attractions-3 "><a href="/investments/#coming-attractions">Coming Attractions</a></li>
			<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-closed-deals-3 last-menu-item"><a href="/investments/#closed-deals">Closed Deals</a></li>
		</ul>
	</div>
</nav>