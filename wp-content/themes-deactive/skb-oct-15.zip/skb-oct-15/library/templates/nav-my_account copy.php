<div class="col-xs-12">
	<ul class="nav nav-tabs" role="tablist" id="my-account">
		<li role="presentation" class="active"><a href="#account" aria-controls="account" role="tab" data-toggle="tab">Account</a></li>
		<li role="presentation"><a href="#verification" aria-controls="verification" role="tab" data-toggle="tab">Verification</a></li>
		<li role="presentation"><a href="#address" aria-controls="address" role="tab" data-toggle="tab">Change Address</a></li>
		<li role="presentation"><a href="#password" aria-controls="password" role="tab" data-toggle="tab">Change Password</a></li>
	</ul>
	<br><br>	
</div>