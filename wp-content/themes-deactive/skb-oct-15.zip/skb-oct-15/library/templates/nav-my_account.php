<div class="col-xs-12">
	<ul class="nav nav-tabs" role="tablist" id="my-account">
		<li role="presentation" class="active"><a href="#account" aria-controls="account" role="tab" data-toggle="tab">Account</a></li>
		<li role="presentation"><a href="#entities" aria-controls="entities" role="tab" data-toggle="tab">Entities</a></li>
		<li role="presentation"><a href="#photo" aria-controls="photo" role="tab" data-toggle="tab">Photo</a></li>
		<li role="presentation"><a href="#address" aria-controls="address" role="tab" data-toggle="tab">Address</a></li>
		<li role="presentation"><a href="#password" aria-controls="password" role="tab" data-toggle="tab">Password</a></li>
                <li role="presentation"><a href="#preferences" aria-controls="entities" role="tab" data-toggle="tab">Preferences</a></li>
	</ul>
	<br><br>	
</div>