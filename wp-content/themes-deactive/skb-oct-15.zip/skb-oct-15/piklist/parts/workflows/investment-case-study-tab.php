<?php
/*
Title: Case Study
Order: 30
Flow: Investment Flow
*/
piklist('include_meta_boxes', array(
    'piklist_meta_post_type_investment_case_study',
    'postimagediv'
    )
);
?>