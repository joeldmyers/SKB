<?php
/*
Title: Investment
Order: 10
Flow: Investment Flow
Default: true
*/
piklist('include_meta_boxes', array(
    'piklist_meta_post_type_investment_details',
    'postimagediv'
    )
);
?>