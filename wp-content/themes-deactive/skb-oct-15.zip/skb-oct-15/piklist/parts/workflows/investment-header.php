<?php
/*
Flow: Investment Flow
Page: post.php, post-new.php, post-edit.php
Post Type: investment
Header: true
Position: title
*/
?>