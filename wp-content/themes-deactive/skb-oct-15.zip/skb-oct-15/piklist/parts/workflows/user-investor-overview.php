<?php
/*
Title: Overview
Order: 20
Flow: User
Tab Order: 20
*/
   
  piklist('include_user_profile_fields', array(
    'meta_boxes' => array(
      'Investor Overview',
    )
  ));

  piklist('shared/code-locater', array(
    'location' => __FILE__
    ,'type' => 'Workflow Tab'
  ));

?>