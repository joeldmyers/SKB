<form role="search" method="get" class="search-products" action="/">
	<div class="input-group">
		<input type="text" name="s" id="s" class="s form-control" autocorrect="off" autocapitalize="off" value="" placeholder="Search products">
		<span class="input-group-btn">
			<button class="btn btn-default" type="button">GO</button>
		</span>
	</div>
	<input type="hidden" name="post_type" value="product">
</form>