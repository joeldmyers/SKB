<?php get_header(); ?>

<div class="container">
	<div class="row">
    	<?php get_template_part( 'library/templates/content' , 'single' ); ?>
    </div>
</div>

<?php get_footer();